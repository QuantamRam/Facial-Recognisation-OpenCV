.. cmake-module:: ../../Modules/CheckCompilerFlag.cmake
